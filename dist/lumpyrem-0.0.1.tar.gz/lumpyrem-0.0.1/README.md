# lumpyrem
Python library to run the LUMPREM software suite.
